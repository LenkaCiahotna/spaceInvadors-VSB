#include <SDL2/SDL.h>

#include <time.h>
#include <stdlib.h>
#include "dynamic_array.h"
#include "sdl.h"
#include "utils.h"
#include "menu.h"
#include "guide.h"
#include "player.h"
#include "enemy.h"

int main()
{
    srand((unsigned int)time(NULL));

    SDL_Context context = sdl_context_init("Space Invadors", WINDOW_WIDTH, WINDOW_HEIGHT);
    TTF_Font* font = TTF_OpenFont("../assets/space_invaders.ttf", 20);
    if (font == NULL) 
    {
        printf("CHYBA: Nepodarilo se nacist font!");
        return 1;
    }
    SDL_Texture* spriteSheet = IMG_LoadTexture(context.renderer, "../assets/spritesheet.png");
     if (spriteSheet == NULL) 
    {
        printf("CHYBA: Nepodarilo se nacist font!");
        return 1;
    }
    MenuContext menuContext =  menuInit(context.renderer, font);
    GuideContext guideContext = guideInit(context.renderer, font);
   
    GameState currentState = STATE_MENU;

   
    SDL_Event event;
    int running = 1;
    Uint64 last = SDL_GetPerformanceCounter();
    while (running == 1)
    {
        Uint64 now = SDL_GetPerformanceCounter();
        double deltaTime = (double)(now - last) / (double)((long long)SDL_GetPerformanceFrequency());
        //akce
        while (SDL_PollEvent(&event))
        {
            if(event.type == SDL_QUIT)
            {
                running = 0;
            }
            if (event.type == SDL_KEYDOWN) 
            {
                //zde M pro mute music?
                switch (currentState)
                {
                    case STATE_MENU:
                        currentState = menuHandleInput(&menuContext, event);
                            break;
                    case STATE_GUIDE:
                        if (event.key.keysym.sym == SDLK_SPACE)
                        {
                            currentState = STATE_MENU;
                        }   
                        break;
                    default:
                    break;
                }
            }
        }

        //nabarvi pozadi
        SDL_SetRenderDrawColor(context.renderer, 0, 0, 0, 255);
        SDL_RenderClear(context.renderer);

        //vykresli dle statu
        switch (currentState)
        {
            case STATE_MENU:
                menuRender(context.renderer, &menuContext);
            break;
            case STATE_GUIDE:
               guideRender(context.renderer, &guideContext);
                break;
            case STATE_GAME:
                //POKKUS
                Player player = playerInit(context.renderer, spriteSheet);
    
                SDL_RenderCopy(context.renderer,player.base.sprite.texture, &player.base.sprite.source,&player.base.sprite.destination);

                /*Enemy enemies[55]; 
                  SDL_Point enemyStart = {32, 32};
                    for (int i = 0; i < 55; i++) 
                    {
                        game.enemies[i] = enemyInit(renderer, sheet, &enemyStart);
                        
                        // Rozmístění do mřížky 11 sloupců a 5 řad
                        int col = i % 11;
                        int row = i / 11;
                        game.enemies[i].base.sprite.destination.x = 50 + (col * 40);
                        game.enemies[i].base.sprite.destination.y = 50 + (row * 40);
                    }*/
                break;
            case STATE_QUIT:
                running = 0;
            break;
        
        default:
            break;
        }
       
        SDL_RenderPresent(context.renderer);
        last = now;
    }
    //uklid
    menuCleanup(&menuContext);
    guideCleanup(&guideContext);
    TTF_CloseFont(font);
    sdl_context_free(&context);
    return 0;
}
