#pragma once

#include <SDL2/SDL.h>
#include <SDL2/SDL_image.h>
#include "defs.h"
#include "player.h"
#include "enemy.h"

typedef struct 
{
   Player player;
   Enemy enemies[55];
   bool isRunning;
   int score;
}Game;

typedef struct 
{
   Game game;
   Sprite items[10];
}GameContext;


