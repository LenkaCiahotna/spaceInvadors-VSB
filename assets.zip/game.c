#include <SDL2/SDL.h>
#include <SDL2/SDL_image.h>
#include "game.h"

/*Game gameInit(SDL_Renderer* renderer, SDL_Texture* sheet, )
{
    Game game;
    memset(&game, 0, sizeof(Game));

    game.player = playerInit(renderer,sheet);

    SDL_Point enemyStart = {32, 32};
    for (int i = 0; i < 55; i++) 
    {
        game.enemies[i] = enemyInit(renderer, sheet, &enemyStart);
        
        // Rozmístění do mřížky 11 sloupců a 5 řad
        int col = i % 11;
        int row = i / 11;
        game.enemies[i].base.sprite.destination.x = 50 + (col * 40);
        game.enemies[i].base.sprite.destination.y = 50 + (row * 40);
    }

}*/